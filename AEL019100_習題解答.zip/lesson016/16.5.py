import random

for i in range(100):   # 控制scores資料組的搜尋次數
    print(i, random.randint(0, 100))