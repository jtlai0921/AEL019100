from traffictools import *

flyingcar = FlyingCar()
flyingcar.show_name()
flyingcar.run()
flyingcar.stop()
flyingcar.take_off()
flyingcar.land()

flyingboatcar = FlyingBoatCar()
flyingboatcar.show_name()
flyingboatcar.run()
flyingboatcar.stop()
flyingboatcar.take_off()
flyingboatcar.land()
flyingboatcar.sail()
flyingboatcar.anchor()
