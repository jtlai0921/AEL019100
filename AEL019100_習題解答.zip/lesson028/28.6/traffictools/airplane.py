class Airplane:
    def __init__(self):
        self._name = 'Airplane'

    def show_name(self):
        print(self._name)

    def take_off(self):
        print('Flying...')

    def land(self):
        print('Land')