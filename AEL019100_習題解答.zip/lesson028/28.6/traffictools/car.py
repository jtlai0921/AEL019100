class Car:
    def __init__(self):
        self._name = 'Car'

    def show_name(self):
        print(self._name)

    def run(self):
        print('Running...')

    def stop(self):
        print('Stop')