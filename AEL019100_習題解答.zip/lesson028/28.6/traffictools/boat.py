class Boat:
    def __init__(self):
        self._name = "Boat"

    def show_name(self):
        print(self._name)

    def sail(self):
        print("Sailing")

    def anchor(self):
        print("Anchor")
