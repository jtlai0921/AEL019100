from shape.circle import *
from shape.rect import *
