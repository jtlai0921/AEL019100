from shape.circle import *
from shape.rectangle import *
from shape.triangle import *
from shape.square import *
