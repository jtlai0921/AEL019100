bottom, height = input(
    '請輸入三角形的底和高，資料之間加入空格：').split()
bottom = float(bottom)
height = float(height)

area = bottom * height / 2
print('三角形面積：', area)
