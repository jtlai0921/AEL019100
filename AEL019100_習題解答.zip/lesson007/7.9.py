radius = input('請輸入圓的半徑：')
radius = float(radius)

area = 3.1415926 * radius ** 2
print('圓面積：', area)
