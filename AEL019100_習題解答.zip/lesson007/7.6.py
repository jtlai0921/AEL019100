name, age, height = input(
    '請輸入姓名、年齡和身高，資料之間加入空格：').split()
age = int(age)
height = float(height)
print(name, age, height)
