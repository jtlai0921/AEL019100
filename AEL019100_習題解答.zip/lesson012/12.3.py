x = [i/10 for i in range(1, 11)]
