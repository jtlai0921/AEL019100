num_list = [n for n in range(1, 101) if n % 2 == 0 and n % 6 != 0]
