def sort_low_to_hight(scores):
    return sorted(scores)


def sort_high_to_low(scores):
    return sorted(scores, reverse = True)
