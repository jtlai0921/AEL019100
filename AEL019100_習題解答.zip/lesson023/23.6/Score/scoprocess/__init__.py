__all__ = ['scocheck', 'scosort']
from scoprocess import *
