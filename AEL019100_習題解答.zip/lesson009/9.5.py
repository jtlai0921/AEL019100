# 輸入考試成績
num = int(input('輸入一個整數：'))

if num % 7 == 0 and num % 13 == 0:
    print("是7和13的公倍數")
else:
    print("不是7和13的公倍數")
