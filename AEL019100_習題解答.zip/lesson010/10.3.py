sum = 0   # 累加變數
for i in range(1, 101, 2):
    sum += i

print(sum)
