for i in range(3, 8, 1):
    for j in range(3, 8, 1):
        print(i, 'x', j, '=', i*j)

    print('----------')
