sum = 0
for i in range(43, 100000001, 43):
    sum += i

print(sum)
