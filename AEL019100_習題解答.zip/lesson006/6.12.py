complex1 = 2-8j
complex2 = 1+5j

add = complex1 + complex2
subtract = complex1 - complex2
multiply = complex1 * complex2
divid = complex1 / complex2

print('相加：', add)
print('相減：', subtract)
print('相乘：', multiply)
print('相除：', divid)