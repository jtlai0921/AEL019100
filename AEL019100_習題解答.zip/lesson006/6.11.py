hours = 40076 / (470 / 0.623)
print('繞赤道一圈需要' , hours, '小時')

speed = 40076 / 24 * 0.623
print('飛機最低時速' , speed, '英哩')
