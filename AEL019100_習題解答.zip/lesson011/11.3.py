my_friend1 = 'John', '男', 18, '0912333333'
my_friend2 = 'Carol', '女', 17, '0912666666'
my_friend3 = 'Lisa', '女', 16, '0912999999'
