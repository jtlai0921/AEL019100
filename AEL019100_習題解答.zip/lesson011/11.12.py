my_friend1 = ['John', '男', 18]
my_friend2 = ['Carol', '女', 17]
my_friend3 = ['Lisa', '女', 16]

my_friend1 += ['0912333333']
my_friend2 += ['0912666666']
my_friend3 += ['0912999999']

contact = [my_friend1, my_friend2, my_friend3]

for friend in contact:
    print(friend)
