my_friend1 = ['John', '男', 18]
my_friend2 = ['Carol', '女', 17]
my_friend3 = ['Lisa', '女', 16]
