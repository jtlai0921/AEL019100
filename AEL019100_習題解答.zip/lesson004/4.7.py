import turtle as tutl

tutl.showturtle()
tutl.color('red')
tutl.pensize(3)
tutl.left(45)
tutl.forward(150)
tutl.left(90)
tutl.forward(150)
tutl.left(90)
tutl.forward(150)
tutl.left(90)
tutl.forward(150)
