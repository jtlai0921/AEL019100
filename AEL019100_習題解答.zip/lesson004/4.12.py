import turtle as tutl

# 向左退到畫第一個圓的位置，然後畫第一個圓
tutl.penup()
tutl.forward(-75)
tutl.pendown()
tutl.circle(50)

# 前進到第二個圓的位置，畫第二個圓
tutl.penup()
tutl.forward(50)
tutl.pendown()
tutl.circle(50)

# 前進到第三個圓的位置，畫第三個圓
tutl.penup()
tutl.forward(50)
tutl.pendown()
tutl.circle(50)

# 前進到第四個圓的位置，畫第四個圓
tutl.penup()
tutl.forward(50)
tutl.pendown()
tutl.circle(50)
